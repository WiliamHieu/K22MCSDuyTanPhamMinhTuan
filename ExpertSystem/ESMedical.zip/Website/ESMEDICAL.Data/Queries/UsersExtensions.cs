﻿using System;
using System.Data.Linq;
using System.Linq;

namespace ESMEDICAL.Data
{
    public static partial class UsersExtensions
    {
        // Place custom query extensions here.
        
        #region Query
        // A private class for lazy loading static compiled queries.
        private static partial class Query
        {
            // Place custom compiled queries here. 
        } 
        #endregion
    }
}