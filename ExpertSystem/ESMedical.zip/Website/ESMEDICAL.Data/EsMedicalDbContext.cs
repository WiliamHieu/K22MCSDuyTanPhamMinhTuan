﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace ESMEDICAL.Data
{
    public partial class EsMedicalDbContext
    {
        #region Extensibility Method Definitions
        //TODO: Uncomment and implement partial method
        //partial void OnCreated()
        //{
        //    
        //}
        #endregion
        
    }
}