﻿using System;
using System.ComponentModel;

namespace ESMEDICAL.Data
{
    /// <summary>
    /// A base class for Linq entities that implements notification events.
    /// </summary>
    public abstract partial class LinqEntityBase
    {
        
    }
}